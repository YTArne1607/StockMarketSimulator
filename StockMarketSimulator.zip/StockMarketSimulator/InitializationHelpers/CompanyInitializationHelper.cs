﻿using Microsoft.VisualBasic;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;

namespace StockMarketSimulator.InitializationHelpers
{
    public class CompanyInitializationHelper
    {
        public static List<Company> InitCompaniesOnApplicationStart()
        {
            Random randomGenerator = new Random();
            List<Company> Companies = new List<Company>();
            List<string> companyNames = new List<string> {
                "AeroTech Systems",
                "AgriNova Foods",
                "Atlas Energy Group",
                "BlueWave Technologies",
                "Crystal Dynamics Pharma",
                "EcoVolt Power",
                "GlobalTrust Bank",
                "IronPeak Industries",
                "Nova Logistics",
                "Skyline Real Estate",
            };

            string subFolder = Path.Combine(Directory.GetCurrentDirectory(), "CompanyFiles");
            Directory.CreateDirectory(subFolder);
            string path = Path.Combine(subFolder, "Companies.json");
            if (!File.Exists(path))
            {
                for (int i = 0; i < companyNames.Count; i++)
                {
                    int revenue = randomGenerator.Next(50000, 2500000 + 1);
                    int expenses = randomGenerator.Next(200000, 3000000 + 1);
                    int employees = randomGenerator.Next(70, 2000 + 1);

                    Company company = new Company
                    {
                        Name = companyNames[i],
                        Employees = employees,
                        Revenue = revenue,
                        Expenses = expenses,
                        Profit = revenue - expenses,
                        Reputation = 80,
                    };

                    Companies.Add(company);
                }

                string json = JsonSerializer.Serialize(Companies);
                File.WriteAllText(path, json);
            }

            string readjson = File.ReadAllText(path);
            Companies = JsonSerializer.Deserialize<List<Company>>(readjson) ?? new List<Company>();

            return Companies;

            //foreach (Company company in Companies)
            // {
            //int revenue = randomGenerator.Next(50000, 400000 + 1);
            //int expenses = randomGenerator.Next(100000, 500000 + 1);
            //int reputation = 80;
            //    new Company()
            //    {
            //        Name = company.Name,
            //        Employees = 170,
            //        Revenue = revenue,
            //        Expenses = expenses,
            //        Profit = revenue - expenses,
            //        Reputation = reputation,
            //    };
            //}

            //Companies = new List<(List<string> name, int employees, int revenue, int expenses, int profit, int reputation)>
            //    {
            //        ("AeroTech Systems", randomGenerator.Next(70, 750 + 1),
            //        ("AgriNova Foods", randomGenerator.Next(70, 750 + 1)),
            //        ("Atlas Energy Group", randomGenerator.Next(70, 750 + 1)),
            //        ("BlueWave Technologies", randomGenerator.Next(70, 750 + 1)),
            //        ("Crystal Dynamics Pharma", randomGenerator.Next(70, 750 + 1)),
            //        ("EcoVolt Power", randomGenerator.Next(70, 750 + 1)),
            //        ("GlobalTrust Bank",randomGenerator.Next(70, 750 + 1)),
            //        ("IronPeak Industries", randomGenerator.Next(70, 750 + 1)),
            //        ("Nova Logistics", randomGenerator.Next(70, 750 + 1)),
            //        ("Skyline Real Estate", randomGenerator.Next(70, 750 + 1))
            //    };


        }
    }
}